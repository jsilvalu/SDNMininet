from sklearn.svm import SVR
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPRegressor
import pickle
import json

def train_model(model, X: list, y: list, out_filename: str):
    model.fit(X, y)
    with open(out_filename, 'wb') as out_model:
        pickle.dump(model, out_model)

def train_linear(X: list, y: list, out_filename: str):
    model = LinearRegression()
    train_model(model, X, y, out_filename)

def train_svm(X: list, y: list, out_filename: str):
    model = SVR(max_iter=10000)
    train_model(model, X, y, out_filename)

def train_neural(X: list, y: list, out_filename: str):
    model = MLPRegressor(max_iter=10000)
    train_model(model, X, y, out_filename)

def train_all_from_files(in_files: list):
    for file in files:
        out_file = file[:-5]
        with open(file, 'r') as in_json:
            data = json.load(in_json)
        X = data['ml_x']
        y = data['ml_y']
        train_linear(X, y, out_file+"Linear.lfp")
        train_neural(X, y, out_file+"Neural.lfp")
        train_svm(X, y, out_file+"SVM.lfp")

if __name__ == "__main__":
    files = ["LINKS_S1_2550.csv.json",
            "LINKS_S2_25100.csv.json",
            "LINKS_S3_25150.csv.json",
            "LINKS_S4_5050.csv.json",
            "LINKS_S5_50100.csv.json",
            "LINKS_S6_50150.csv.json",
            "LINKS_S7_7550.csv.json",
            "LINKS_S8_75100.csv.json",
            "LINKS_S9_75150.csv.json",]
    train_all_from_files(files)
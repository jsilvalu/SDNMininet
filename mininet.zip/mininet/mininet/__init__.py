"Docstring to silence pylint; ignores --ignore option for __init__.py"

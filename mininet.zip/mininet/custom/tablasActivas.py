#!/usr/bin/python

""" tablasActivas.py 
Envian solicitudes de estadísticas de la tabla cuando existe conexion con el controlador
y los switches. Cuando el controlador recibe el evento -TableStatsReceived- envia durante
cierto intervalo que see introduce por parametros.

sudo ./pox/pox.py tableStat --interval=1
sudo ./pox.py opennetmon.startup forwarding.l2_learning tableStat --interval=1

La salida es un diccionario como:
{'s3': 0, 's2': 0, 's1': 0, 's6': 0, 's5': 0, 's4': 0}
-----------------------------------------------------------------------------------------

"""

from pox.core import core  
import pox.openflow.libopenflow_01 as of  
from pox.lib.revent import *  
from pox.lib.recoco import Timer  
from collections import defaultdict  
from pox.openflow.discovery import Discovery  
from pox.lib.util import dpid_to_str  
import time



class tableStats(EventMixin):  
  def __init__(self,interval = 10):
    self.tableActiveCount = {}
    self.interval = interval
    core.openflow.addListeners(self)

  def _handle_ConnectionUp(self,event):
    print "Switch %s has connected" %event.dpid
    self.sendTableStatsRequest(event)

  def _handle_TableStatsReceived(self,event):
    sw = 's%s'%event.dpid
    self.tableActiveCount[sw] = event.stats[0].active_count
    print "TableStatsReceived"
    print self.tableActiveCount
    Timer(self.interval, self.sendTableStatsRequest,args=[event])

  def sendTableStatsRequest(self, event):
    sr = of.ofp_stats_request()
    sr.type = of.OFPST_TABLE
    event.connection.send(sr)
    print "Send table stat message to Switch %s " %event.dpid




def launch(interval = '10'):  
  interval = int(interval)
  core.registerNew(tableStats,interval)

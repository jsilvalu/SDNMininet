packet_count = 0
byte_count = 0
duration_msec = 0
is_count = 0
diff_arr = []
diff_avg = 0
prev_duration_msec = 0
prev_packet_count = 0
